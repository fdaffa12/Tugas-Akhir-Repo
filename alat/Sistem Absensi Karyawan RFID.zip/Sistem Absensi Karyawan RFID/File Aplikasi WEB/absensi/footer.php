<div class="footer" style="text-align: center">
	Youtube Channel : Koding Perangkat <br>
	<strong>SUBSCRIBE | LIKE | SHARE | COMMENT</strong>
</div>