<?php
	//urutan = server, userdb, passdb, namadb
	$konek = mysqli_connect("localhost", "root", "", "absenrfid");
?>